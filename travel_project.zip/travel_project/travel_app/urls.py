from django.urls import path
from .views import TravelAPIView, KlassAPIView, MehmonxonaAPIView

urlpatterns = [
    path('klass/', KlassAPIView.as_view(), name='klass_api'),
    path('klass/<int:pk>/', KlassAPIView.as_view(), name='klass_detail'),
    path('mehmonxona/', MehmonxonaAPIView.as_view(), name='mehmonxona_api'),
    path('mehmonxona/<int:pk>/', MehmonxonaAPIView.as_view(), name='mehmonxona_detail'),
    path('travel/', TravelAPIView.as_view(), name='travel_api'),
    path('travel/<int:pk>/', TravelAPIView.as_view(), name='travel_detail'),
]

# apilar pastda turbdi

# http://127.0.0.1:8000/api/klass/
# http://127.0.0.1:8000/api/mehmonxona/
# http://127.0.0.1:8000/api/travel/